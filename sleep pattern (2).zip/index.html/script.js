function calculateCycles() {
  const results = document.getElementById("results");
  results.innerHTML = "";
  const now = new Date();

  for (let i = 1; i <= 10; i++) {
    const wakeUpTime = new Date(now.getTime() + i * 90 * 60000);
    const hours = wakeUpTime.getHours().toString().padStart(2, '0');
    const minutes = wakeUpTime.getMinutes().toString().padStart(2, '0');
    const listItem = document.createElement("li");
    listItem.textContent = `لو نمت دلوقتي، صحي بعد ${i} دورة: ${hours}:${minutes}`;
    results.appendChild(listItem);
  }
}
