function calculateCycles() {
  const input = document.getElementById("sleepTime").value;
  const results = document.getElementById("results");
  if (!input) return;

  const [hours, minutes] = input.split(":").map(Number);
  const base = new Date();
  base.setHours(hours, minutes, 0, 0);

  const cycleLength = 90; // minutes
  const cycles = [1, 2, 3, 4, 5, 6];
  let output = "<h3>Wake up at:</h3><ul>";

  for (let c of cycles) {
    const wake = new Date(base.getTime() + c * cycleLength * 60000);
    output += `<li>${wake.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} (${c} cycles)</li>`;
  }

  output += "</ul>";
  results.innerHTML = output;

  notifyUser("Sleep cycles calculated ✅");
}

function sleepNow() {
  const now = new Date();
  const cycleLength = 90;
  const results = document.getElementById("results");
  let output = "<h3>Wake up at:</h3><ul>";

  for (let c = 3; c <= 6; c++) {
    const wake = new Date(now.getTime() + c * cycleLength * 60000 + 15 * 60000); // 15 min to fall asleep
    output += `<li>${wake.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} (${c} cycles)</li>`;
  }

  output += "</ul>";
  results.innerHTML = output;

  notifyUser("Sleep now times calculated 💤");
}

function notifyUser(msg) {
  if (Notification.permission === "granted") {
    new Notification(msg);
  } else if (Notification.permission !== "denied") {
    Notification.requestPermission().then(permission => {
      if (permission === "granted") {
        new Notification(msg);
      }
    });
  }
}

document.getElementById("langSelector").addEventListener("change", function () {
  const lang = this.value;
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";

  document.getElementById("title").textContent = lang === "ar" ? "دورات النوم" : "Sleep Patterns";
  document.getElementById("timeLabel").textContent = lang === "ar" ? "حدد وقت النوم:" : "Select sleep time:";
  document.getElementById("calculateBtn").textContent = lang === "ar" ? "احسب" : "Calculate";
  document.getElementById("sleepNowBtn").textContent = lang === "ar" ? "نام الآن" : "Sleep Now";
});
